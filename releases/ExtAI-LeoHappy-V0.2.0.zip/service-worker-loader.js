import './assets/index.ts-C_veDcAt.js';
