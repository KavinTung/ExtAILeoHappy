var R=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function B(i){return i&&i.__esModule&&Object.prototype.hasOwnProperty.call(i,"default")?i.default:i}var L={exports:{}};(function(i,F){(function(v,f){f(i)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:R,function(v){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)v.exports=globalThis.browser;else{const f="The message port closed before a response was received.",S=A=>{const y={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(y).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class E extends WeakMap{constructor(n,r=void 0){super(r),this.createItem=n}get(n){return this.has(n)||this.set(n,this.createItem(n)),super.get(n)}}const U=e=>e&&typeof e=="object"&&typeof e.then=="function",C=(e,n)=>(...r)=>{A.runtime.lastError?e.reject(new Error(A.runtime.lastError.message)):n.singleCallbackArg||r.length<=1&&n.singleCallbackArg!==!1?e.resolve(r[0]):e.resolve(r)},x=e=>e==1?"argument":"arguments",D=(e,n)=>function(s,...a){if(a.length<n.minArgs)throw new Error(`Expected at least ${n.minArgs} ${x(n.minArgs)} for ${e}(), got ${a.length}`);if(a.length>n.maxArgs)throw new Error(`Expected at most ${n.maxArgs} ${x(n.maxArgs)} for ${e}(), got ${a.length}`);return new Promise((m,l)=>{if(n.fallbackToNoCallback)try{s[e](...a,C({resolve:m,reject:l},n))}catch(t){console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,t),s[e](...a),n.fallbackToNoCallback=!1,n.noCallback=!0,m()}else n.noCallback?(s[e](...a),m()):s[e](...a,C({resolve:m,reject:l},n))})},N=(e,n,r)=>new Proxy(n,{apply(s,a,m){return r.call(a,e,...m)}});let p=Function.call.bind(Object.prototype.hasOwnProperty);const b=(e,n={},r={})=>{let s=Object.create(null),a={has(l,t){return t in e||t in s},get(l,t,o){if(t in s)return s[t];if(!(t in e))return;let g=e[t];if(typeof g=="function")if(typeof n[t]=="function")g=N(e,e[t],n[t]);else if(p(r,t)){let h=D(t,r[t]);g=N(e,e[t],h)}else g=g.bind(e);else if(typeof g=="object"&&g!==null&&(p(n,t)||p(r,t)))g=b(g,n[t],r[t]);else if(p(r,"*"))g=b(g,n[t],r["*"]);else return Object.defineProperty(s,t,{configurable:!0,enumerable:!0,get(){return e[t]},set(h){e[t]=h}}),g;return s[t]=g,g},set(l,t,o,g){return t in s?s[t]=o:e[t]=o,!0},defineProperty(l,t,o){return Reflect.defineProperty(s,t,o)},deleteProperty(l,t){return Reflect.deleteProperty(s,t)}},m=Object.create(e);return new Proxy(m,a)},T=e=>({addListener(n,r,...s){n.addListener(e.get(r),...s)},hasListener(n,r){return n.hasListener(e.get(r))},removeListener(n,r){n.removeListener(e.get(r))}}),I=new E(e=>typeof e!="function"?e:function(r){const s=b(r,{},{getContent:{minArgs:0,maxArgs:0}});e(s)}),_=new E(e=>typeof e!="function"?e:function(r,s,a){let m=!1,l,t=new Promise(d=>{l=function(u){m=!0,d(u)}}),o;try{o=e(r,s,l)}catch(d){o=Promise.reject(d)}const g=o!==!0&&U(o);if(o!==!0&&!g&&!m)return!1;const h=d=>{d.then(u=>{a(u)},u=>{let w;u&&(u instanceof Error||typeof u.message=="string")?w=u.message:w="An unexpected error occurred",a({__mozWebExtensionPolyfillReject__:!0,message:w})}).catch(u=>{console.error("Failed to send onMessage rejected reply",u)})};return h(g?o:t),!0}),M=({reject:e,resolve:n},r)=>{A.runtime.lastError?A.runtime.lastError.message===f?n():e(new Error(A.runtime.lastError.message)):r&&r.__mozWebExtensionPolyfillReject__?e(new Error(r.message)):n(r)},P=(e,n,r,...s)=>{if(s.length<n.minArgs)throw new Error(`Expected at least ${n.minArgs} ${x(n.minArgs)} for ${e}(), got ${s.length}`);if(s.length>n.maxArgs)throw new Error(`Expected at most ${n.maxArgs} ${x(n.maxArgs)} for ${e}(), got ${s.length}`);return new Promise((a,m)=>{const l=M.bind(null,{resolve:a,reject:m});s.push(l),r.sendMessage(...s)})},O={devtools:{network:{onRequestFinished:T(I)}},runtime:{onMessage:T(_),onMessageExternal:T(_),sendMessage:P.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:P.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},k={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return y.privacy={network:{"*":k},services:{"*":k},websites:{"*":k}},b(A,O,y)};v.exports=S(chrome)}})})(L);var V=L.exports;const K=B(V),G=[{id:"improve-writing",label:"Improve Writing",icon:"Sparkles",defaultTemplateId:"default.improve-writing.v1"},{id:"summarize",label:"Summarize",icon:"FileText",defaultTemplateId:"default.summarize.v1"},{id:"translate-vi",label:"Translate to Vietnamese",icon:"Languages",defaultTemplateId:"default.translate-vi.v1"},{id:"currency-vnd",label:"Convert Currency to VND",icon:"Coins",defaultTemplateId:"default.currency-vnd.v1"},{id:"explain",label:"Explain",icon:"Lightbulb",defaultTemplateId:"default.explain.v1"},{id:"search-web",label:"Search Web",icon:"Search",defaultTemplateId:"default.search-web-query.v1"},{id:"continue-chat",label:"Continue Chat",icon:"MessageSquare",defaultTemplateId:"default.continue-chat.v1"}],c=17e11,H=[{id:"default.improve-writing.v1",name:"Improve Writing",actionType:"improve-writing",description:"Cải thiện văn phong rõ ràng, tự nhiên và đúng ngữ pháp, giữ nguyên ý nghĩa gốc.",version:1,systemPrompt:`Bạn là chuyên gia biên tập và cải thiện văn bản.
Hãy cải thiện văn bản người dùng cung cấp về ngữ pháp, độ rõ ràng, sự mạch lạc và độ tự nhiên.
Giữ nguyên ý nghĩa gốc. Không thêm thông tin mới không có trong văn bản.
Không thay đổi thuật ngữ chuyên môn nếu không cần thiết.
Trả về trực tiếp phiên bản đã cải thiện để người dùng sao chép nhanh.`,userPrompt:`Hãy cải thiện văn bản sau.

Yêu cầu:
- Giữ nguyên ý nghĩa gốc.
- Sửa lỗi ngữ pháp, chính tả, diễn đạt.
- Làm câu văn tự nhiên và chuyên nghiệp hơn.
- Tone mong muốn: {tone}.
- Định dạng: {format}.
- Nếu văn bản gốc là tiếng Việt, trả kết quả bằng tiếng Việt. Nếu là tiếng Anh hoặc ngôn ngữ khác, giữ đúng ngôn ngữ gốc trừ khi được yêu cầu khác.

Văn bản:

<selected_text>
{selectedText}
</selected_text>`,outputExpectations:"Trả trực tiếp bản đã cải thiện theo ngôn ngữ gốc của văn bản.",variables:["selectedText","tone","format","pageTitle","pageUrl"],defaults:{tone:"Natural",format:"Plain text / Markdown"},isDefault:!0,isActive:!0,isUserCreated:!1,createdAt:c,updatedAt:c},{id:"default.summarize.v1",name:"Summarize",actionType:"summarize",description:"Tóm tắt ngắn gọn các ý chính theo dạng bullet points, không bịa thêm.",version:1,systemPrompt:`Bạn là trợ lý tóm tắt nội dung.
Hãy tóm tắt chính xác nội dung người dùng cung cấp.
Không thêm thông tin ngoài văn bản.
Nếu văn bản quá ngắn hoặc không đủ thông tin, hãy nêu rõ.`,userPrompt:`Hãy tóm tắt nội dung sau bằng {targetLanguage}.

Yêu cầu:
- Độ dài: {length}.
- Ưu tiên các ý chính, trình bày rõ ràng.
- Không bịa thêm thông tin ngoài văn bản.
- Format: {format}.

Ngữ cảnh trang nếu có:
- Tiêu đề: {pageTitle}
- URL: {pageUrl}

Nội dung:

<selected_text>
{selectedText}
</selected_text>`,outputExpectations:"Trả lời bằng bullet list Markdown kèm tiêu đề ngắn nếu phù hợp.",variables:["selectedText","targetLanguage","length","format","pageTitle","pageUrl"],defaults:{targetLanguage:"Vietnamese",length:"Short",format:"Bullet points"},isDefault:!0,isActive:!0,isUserCreated:!1,createdAt:c,updatedAt:c},{id:"default.translate-vi.v1",name:"Translate to Vietnamese",actionType:"translate-vi",description:"Dịch văn bản sang tiếng Việt tự nhiên, giữ thuật ngữ, mã và số liệu.",version:1,systemPrompt:`Bạn là biên dịch viên chuyên nghiệp.
Hãy dịch văn bản sang tiếng Việt tự nhiên, chính xác và dễ hiểu.
Giữ nguyên ý nghĩa, thuật ngữ kỹ thuật quan trọng, tên riêng, mã, URL, email, số liệu và định dạng cơ bản.
Không thêm giải thích thừa nếu người dùng không yêu cầu.`,userPrompt:`Dịch văn bản sau sang {targetLanguage}.

Yêu cầu:
- Dịch tự nhiên, không máy móc.
- Giữ nguyên tên riêng, mã/code, URL, email, số liệu.
- Giữ định dạng danh sách hoặc đoạn văn nếu có.
- Tone: {tone}.
- Chỉ trả về bản dịch.

Văn bản:

<selected_text>
{selectedText}
</selected_text>`,outputExpectations:"Chỉ trả về bản dịch tiếng Việt tự nhiên, giữ cấu trúc gốc.",variables:["selectedText","targetLanguage","tone"],defaults:{targetLanguage:"Vietnamese",tone:"Natural"},isDefault:!0,isActive:!0,isUserCreated:!1,createdAt:c,updatedAt:c},{id:"default.currency-vnd.v1",name:"Convert Currency to VND",actionType:"currency-vnd",description:"Nhận diện số tiền và quy đổi sang VND kèm cảnh báo tỷ giá tham khảo.",version:1,systemPrompt:`Bạn là trợ lý quy đổi tiền tệ sang VND.
Nhiệm vụ của bạn là nhận diện các khoản tiền trong văn bản và quy đổi sang VND.
Nếu được cung cấp dữ liệu tỷ giá trong <currency_rates>, hãy dùng chính xác tỷ giá đó.
Nếu không có dữ liệu tỷ giá thời gian thực được cung cấp (giá trị trống hoặc "Không có"), tuyệt đối KHÔNG khẳng định là tỷ giá mới nhất/real-time; bạn có thể ước lượng theo tỷ giá tham khảo phổ biến nhưng BẮT BUỘC phải ghi rõ: "Lưu ý: Kết quả sử dụng tỷ giá tham khảo ước lượng, không phải tỷ giá thời gian thực."
Nếu văn bản không chứa số tiền hay đơn vị tiền tệ nào, hãy nói rõ.`,userPrompt:`Hãy nhận diện và quy đổi các số tiền trong văn bản sau sang VND.

Tỷ giá được cung cấp:
<currency_rates>
{currencyRates}
</currency_rates>

Ngày hiện tại / ngày tỷ giá: {currencyConversionDate}

Yêu cầu:
- Trình bày bằng bảng Markdown rõ ràng: Khoản tiền gốc | Tỷ giá sử dụng | Kết quả ước tính (VND).
- Nếu có tỷ giá trong <currency_rates>, sử dụng đúng tỷ giá đó và trình bày phép tính ngắn gọn.
- Nếu không có tỷ giá thời gian thực, hãy ghi rõ ước tính theo tỷ giá tham khảo và kèm cảnh báo tỷ giá tham khảo ở cuối.
- Làm tròn VND dễ đọc (ví dụ: 250.000 VND).

Văn bản:

<selected_text>
{selectedText}
</selected_text>`,outputExpectations:"Bảng Markdown quy đổi sang VND kèm phép tính và disclaimer tỷ giá tham khảo.",variables:["selectedText","currencyRates","currencyConversionDate"],defaults:{currencyRates:"Không có dữ liệu tỷ giá thời gian thực (chế độ MVP ước lượng tham khảo)"},isDefault:!0,isActive:!0,isUserCreated:!1,createdAt:c,updatedAt:c},{id:"default.explain.v1",name:"Explain",actionType:"explain",description:"Giải thích nội dung rõ ràng, có cấu trúc và giải nghĩa thuật ngữ.",version:1,systemPrompt:`Bạn là trợ lý giải thích khái niệm.
Hãy giải thích nội dung người dùng cung cấp một cách rõ ràng, dễ hiểu và có cấu trúc Markdown.
Nếu nội dung có thuật ngữ chuyên môn, hãy giải thích bằng ngôn ngữ đơn giản.
Không bịa thông tin ngoài dữ liệu nếu không chắc chắn; nếu cần suy luận hãy nói rõ.`,userPrompt:`Hãy giải thích nội dung sau bằng {targetLanguage}.

Yêu cầu:
- Mức độ: {explainLevel}.
- Giải thích ngắn gọn ý chính, sau đó giải thích các thuật ngữ quan trọng và đưa ví dụ dễ hiểu nếu phù hợp.
- Nếu nội dung mơ hồ, hãy nêu các cách hiểu có thể.

Ngữ cảnh trang nếu có:
- Tiêu đề trang: {pageTitle}
- URL: {pageUrl}

Nội dung cần giải thích:

<selected_text>
{selectedText}
</selected_text>`,outputExpectations:"Markdown có mục Giải thích ngắn, Ý chính, Thuật ngữ (nếu có).",variables:["selectedText","targetLanguage","explainLevel","pageTitle","pageUrl"],defaults:{targetLanguage:"Vietnamese",explainLevel:"Beginner-friendly"},isDefault:!0,isActive:!0,isUserCreated:!1,createdAt:c,updatedAt:c},{id:"default.search-web-query.v1",name:"Search Web",actionType:"search-web",description:"Tạo 3–5 truy vấn tìm kiếm tối ưu và gợi ý nguồn kiểm chứng (MVP Query Assistant).",version:1,systemPrompt:`Bạn là trợ lý tạo truy vấn tìm kiếm web.
QUAN TRỌNG: Bạn KHÔNG có công cụ truy cập Internet trong chế độ MVP này. Tuyệt đối KHÔNG tuyên bố bạn đã tìm kiếm web, đã mở trang web hay đã đọc kết quả tìm kiếm.
Nhiệm vụ của bạn là phân tích văn bản và đề xuất 3–5 truy vấn tìm kiếm chính xác kèm gợi ý nguồn kiểm chứng đáng tin cậy.`,userPrompt:`Tạo truy vấn tìm kiếm web tốt nhất dựa trên nội dung sau.

Yêu cầu:
- Trả lời bằng {targetLanguage}.
- Đề xuất 3–5 search queries ngắn gọn, rõ từ khóa chính (đặt mỗi query trong backticks).
- Nếu là lỗi kỹ thuật, giữ nguyên mã lỗi/thông báo lỗi chính xác trong query.
- Nếu là thuật ngữ/khái niệm, tạo query để tìm tài liệu chính thức và ví dụ.
- Gợi ý nơi nên tìm (tài liệu chính thức, cộng đồng uy tín...).
- Nhắc rõ lưu ý rằng ExtAI đang ở chế độ gợi ý truy vấn (chưa tự duyệt web).

Ngữ cảnh trang:
- Tiêu đề trang: {pageTitle}
- URL: {pageUrl}

Nội dung:

<selected_text>
{selectedText}
</selected_text>`,outputExpectations:"Danh sách 3–5 truy vấn tìm kiếm Markdown + gợi ý nguồn, không giả mạo kết quả web.",variables:["selectedText","targetLanguage","pageTitle","pageUrl"],defaults:{targetLanguage:"Vietnamese"},isDefault:!0,isActive:!0,isUserCreated:!1,createdAt:c,updatedAt:c},{id:"default.continue-chat.v1",name:"Continue Chat",actionType:"continue-chat",description:"Tiếp tục trò chuyện dựa trên đoạn văn bản đã chọn và lịch sử hội thoại.",version:1,systemPrompt:`Hãy tiếp tục cuộc trò chuyện dựa trên ngữ cảnh đã có.
Trả lời đúng trọng tâm câu hỏi hoặc yêu cầu mới nhất của người dùng.
Nếu thiếu thông tin, hãy hỏi lại hoặc nêu rõ giả định.`,userPrompt:`Tiếp tục cuộc trò chuyện dựa trên ngữ cảnh sau.

Selected text ban đầu nếu có:
<selected_text>
{selectedText}
</selected_text>

Ngữ cảnh hội thoại trước nếu có:
<conversation_context>
{conversationHistory}
</conversation_context>

Câu trả lời gần nhất của trợ lý nếu có:
<last_assistant_message>
{lastAssistantMessage}
</last_assistant_message>

Yêu cầu mới của người dùng:
<user_message>
{userInput}
</user_message>`,outputExpectations:"Trả lời trực tiếp theo ngôn ngữ của người dùng, dựa trên ngữ cảnh đã cung cấp.",variables:["selectedText","conversationHistory","lastAssistantMessage","userInput","pageTitle","pageUrl"],defaults:{userInput:"Hãy phân tích và hỗ trợ tôi dựa trên đoạn nội dung này."},isDefault:!0,isActive:!0,isUserCreated:!1,createdAt:c,updatedAt:c}];var q=(i=>(i.EXECUTE_QUICK_ACTION="EXECUTE_QUICK_ACTION",i.CHAT_SEND="CHAT_SEND",i.VALIDATE_API_KEY="VALIDATE_API_KEY",i.LIST_MODELS="LIST_MODELS",i.GET_JOB_RESULT="GET_JOB_RESULT",i.CANCEL_JOB="CANCEL_JOB",i.GET_CONTENT_STATUS="GET_CONTENT_STATUS",i.OPEN_OPTIONS="OPEN_OPTIONS",i.OPEN_POPUP="OPEN_POPUP",i))(q||{});const $={name:"ExtAI Leo Happy",vendor:"By KaviTeam",url:"https://kavil.ink",privacyUrl:"https://kavil.ink/privacy/extai-leo-happy",version:"0.1.0"},j=100,W=350;export{$ as B,W as D,j as M,G as Q,q as a,K as b,H as c,R as d,B as g};
