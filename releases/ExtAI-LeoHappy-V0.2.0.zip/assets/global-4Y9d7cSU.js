import{c as y,j as c,a as O,n as I,r as w,g as $}from"./cn-UEV3gACG.js";import{B as x,g as R}from"./index-CJyvQd4T.js";/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=y("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=y("History",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M12 7v5l4 2",key:"1fdv2h"}]]);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=y("Moon",[["path",{d:"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z",key:"a7tn18"}]]);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const fe=y("Sun",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const me=y("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))s(r);new MutationObserver(r=>{for(const o of r)if(o.type==="childList")for(const a of o.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&s(a)}).observe(document,{childList:!0,subtree:!0});function n(r){const o={};return r.integrity&&(o.integrity=r.integrity),r.referrerPolicy&&(o.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?o.credentials="include":r.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function s(r){if(r.ep)return;r.ep=!0;const o=n(r);fetch(r.href,o)}})();function pe({subtitle:e=x.vendor,onBack:t,actions:n,compact:s=!1,className:r}){return c.jsxs("header",{className:I("flex items-center justify-between border-b border-neutral-200 bg-white dark:border-neutral-800 dark:bg-neutral-950",s?"px-3 py-2":"px-4 py-3",r),children:[c.jsxs("div",{className:"flex min-w-0 items-center gap-2.5",children:[t&&c.jsx("button",{type:"button",onClick:t,className:"rounded-md p-1 text-neutral-600 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800","aria-label":"Back",children:c.jsx(z,{className:"h-4 w-4"})}),c.jsx(O,{size:s?24:28,className:"shrink-0"}),c.jsxs("div",{className:"min-w-0",children:[c.jsx("h1",{className:"truncate text-sm font-semibold text-neutral-900 dark:text-neutral-100",children:x.name}),c.jsx("p",{className:"truncate text-[11px] text-neutral-500 dark:text-neutral-400",children:e})]})]}),n?c.jsx("div",{className:"flex shrink-0 items-center gap-1",children:n}):c.jsx("a",{href:x.url,target:"_blank",rel:"noreferrer",className:"text-xs font-medium text-leo-dark hover:underline dark:text-leo",children:"kavil.ink"})]})}const V={},E=e=>{let t;const n=new Set,s=(u,f)=>{const l=typeof u=="function"?u(t):u;if(!Object.is(l,t)){const i=t;t=f??(typeof l!="object"||l===null)?l:Object.assign({},t,l),n.forEach(d=>d(t,i))}},r=()=>t,h={setState:s,getState:r,getInitialState:()=>v,subscribe:u=>(n.add(u),()=>n.delete(u)),destroy:()=>{(V?"production":void 0)!=="production"&&console.warn("[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."),n.clear()}},v=t=e(s,r,h);return h},A=e=>e?E(e):E;var M={exports:{}},_={},N={exports:{}},D={};/**
 * @license React
 * use-sync-external-store-shim.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var m=w;function P(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var T=typeof Object.is=="function"?Object.is:P,C=m.useState,H=m.useEffect,B=m.useLayoutEffect,W=m.useDebugValue;function F(e,t){var n=t(),s=C({inst:{value:n,getSnapshot:t}}),r=s[0].inst,o=s[1];return B(function(){r.value=n,r.getSnapshot=t,g(r)&&o({inst:r})},[e,n,t]),H(function(){return g(r)&&o({inst:r}),e(function(){g(r)&&o({inst:r})})},[e]),W(n),n}function g(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!T(e,n)}catch{return!0}}function G(e,t){return t()}var U=typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"?G:F;D.useSyncExternalStore=m.useSyncExternalStore!==void 0?m.useSyncExternalStore:U;N.exports=D;var q=N.exports;/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var b=w,K=q;function Z(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var J=typeof Object.is=="function"?Object.is:Z,Q=K.useSyncExternalStore,X=b.useRef,Y=b.useEffect,ee=b.useMemo,te=b.useDebugValue;_.useSyncExternalStoreWithSelector=function(e,t,n,s,r){var o=X(null);if(o.current===null){var a={hasValue:!1,value:null};o.current=a}else a=o.current;o=ee(function(){function h(i){if(!v){if(v=!0,u=i,i=s(i),r!==void 0&&a.hasValue){var d=a.value;if(r(d,i))return f=d}return f=i}if(d=f,J(u,i))return d;var S=s(i);return r!==void 0&&r(d,S)?(u=i,d):(u=i,f=S)}var v=!1,u,f,l=n===void 0?null:n;return[function(){return h(t())},l===null?void 0:function(){return h(l())}]},[t,n,s,r]);var p=Q(e,o[0],o[1]);return Y(function(){a.hasValue=!0,a.value=p},[p]),te(p),p};M.exports=_;var re=M.exports;const ne=R(re),L={},{useDebugValue:oe}=$,{useSyncExternalStoreWithSelector:se}=ne;let k=!1;const ae=e=>e;function ue(e,t=ae,n){(L?"production":void 0)!=="production"&&n&&!k&&(console.warn("[DEPRECATED] Use `createWithEqualityFn` instead of `create` or use `useStoreWithEqualityFn` instead of `useStore`. They can be imported from 'zustand/traditional'. https://github.com/pmndrs/zustand/discussions/1937"),k=!0);const s=se(e.subscribe,e.getState,e.getServerState||e.getInitialState,t,n);return oe(s),s}const j=e=>{(L?"production":void 0)!=="production"&&typeof e!="function"&&console.warn("[DEPRECATED] Passing a vanilla store will be unsupported in a future version. Instead use `import { useStore } from 'zustand'`.");const t=typeof e=="function"?A(e):e,n=(s,r)=>ue(t,s,r);return Object.assign(n,t),n},he=e=>e?j(e):j;export{pe as B,le as H,de as M,fe as S,me as T,he as c};
